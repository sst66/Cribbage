
import pygame
from pygame import Vector2
from itertools import combinations
import math

# written using VSCode with Pygame 2.1.2 (SDL 2.0.18) and Python 3.9.5

# open the 'game' folder in VSCode (not the files). 
# either right click the 'game' folder and select 'Open with Code'
# or within the VSCode File menu, select 'Open Folder' and browse
# to and select the 'game' folder 

# run 'cribbage.py' from within VSCode or navigate your cmd window to
# the 'game' folder containing the .py files and execute 'cribbage.py'

# Note: be sure the ExternalData folder remains in the Cribbage folder
# next to the game folder as follows

#       Cribbage
#        /    \
#    game      ExternalData
#     |              |
# .py files      image folders

# This code is free and open source
# Feel free to use/edit/distribute as you see fit
# I will not be responsible for anything it does 
# to anything, use at your own risk


pygame.font.init()
small_font = pygame.font.Font('../ExternalData/font/AveriaBold.ttf', 20)


class Scorekeeper(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load('../ExternalData/UI/scorekeeper_rounded.png')
        self.rect = self.image.get_rect(topleft = (950, 10))
        

class ScoreCard(pygame.sprite.Sprite):
    def __init__(self, pos, name):
        super().__init__()
        self.image = pygame.Surface((551, 316)).convert_alpha() # 568 x 188
        self.image.fill((200, 200, 200, 100))

        self.image_top = pygame.image.load('../ExternalData/UI/scorecard_top.png').convert_alpha()

        self.image_middle = pygame.image.load('../ExternalData/UI/scorecard_middle.png').convert_alpha()

        self.image_bottom = pygame.image.load('../ExternalData/UI/scorecard_bottom.png').convert_alpha()
        
        self.suits = 0
        self.nobs = 0

        self.draw_lines()

        self.color = 'antiquewhite'
        self.background_color = (0, 40, 0, 100)
        self.shadow_color = 'black'
        self.pos = pos
        self.name = name
        self.small_font = pygame.font.Font('../ExternalData/font/AveriaBold.ttf', 35)
        self.medium_font = pygame.font.Font('../ExternalData/font/AveriaBold.ttf', 50)
        self.large_font = pygame.font.Font('../ExternalData/font/AveriaBold.ttf', 90)
        
        self.score_runs = 0
        self.score_15s = 0
        self.score_pairs = 0
        self.score_suits = 0
        self.score_nobs = 0

        self.get_self_rect()
        
        self.draw_card_title()

        self.init_images()

    
    def draw_lines(self):
        self.image.blit(self.image_top, (0, 0))
        if self.suits > 0 or self.nobs > 0:
            self.image.blit(self.image_middle, (0, 174), (0, 0 , self.image.get_width(), self.image.get_height() - 200))
        else:
            self.image.blit(self.image_middle, (0, 144), (0, 0 , self.image.get_width(), self.image.get_height() - 160))
        
        self.image.blit(self.image_bottom, (0, self.image.get_height() - 37))

    def init_images(self):
        self.sets_of_run_image = pygame.Surface((10, 0)).convert_alpha()
        self.sets_of_run_rect = self.sets_of_run_image.get_rect(topleft = (9, 222))

        self.sets_of_15_image = pygame.Surface((10, 0)).convert_alpha()
        self.sets_of_15_rect = self.sets_of_15_image.get_rect(topleft = (211, 222))

        self.sets_of_pair_image = pygame.Surface((10, 0)).convert_alpha()
        self.sets_of_pair_rect = self.sets_of_pair_image.get_rect(topleft = (413, 222))

    def draw_card_title(self):
        if self.name == 'player':
            surf = self.get_surf('Your hand', (140, 24), self.small_font)
            self.image.blit(surf[0], surf[1])
        elif self.name == 'crib':
            surf = self.get_surf('Crib', (140, 24), self.small_font)
            self.image.blit(surf[0], surf[1])
        else:
            surf = self.get_surf('CPU hand', (140, 24), self.small_font)
            self.image.blit(surf[0], surf[1])


    def get_self_rect(self):
        if self.name == 'player':
            self.rect = self.image.get_rect(bottomright = self.pos)
        elif self.name == 'crib':
            self.rect = self.image.get_rect(topleft = self.pos)
        else:
            self.rect = self.image.get_rect(topleft = self.pos)
            
    def sort_c(self, card):
        return card.value

    def sort_cards(self, hand):
        return sorted(hand, key=self.sort_c)

    def sort_imgs(self, img):
        return img.get_height()

    def get_score(self, hand, cut_card = None):
        if not hand:
            print('you must send a hand to score it! RETURNING')
            return
        self.hand = self.sort_cards([card for card in hand])
        
        self.sets_of_run_image = pygame.Surface((0, 0)).convert_alpha()
        self.sets_of_15_image = pygame.Surface((0, 0)).convert_alpha()
        self.sets_of_pair_image = pygame.Surface((0, 0)).convert_alpha()

        self.suits = self.get_suits()
        if cut_card:
            if self.suits > 0 and cut_card.suit == self.hand[0].suit:
                self.suits += 1
            self.nobs = self.get_nobs(cut_card)
            self.hand.append(cut_card)
            self.hand = self.sort_cards(self.hand)

        runs3 = 0
        runs4 = 0 
        runs5 = 0

        _15s = self.get_15s()
        pairs = self.get_pairs()
        runs5 = self.get_runs_of_five()
        if not runs5:
            runs4 = self.get_runs_of_four()
            if not runs4:
                runs3 = self.get_runs_of_three()
        runs_total = runs3 + runs4 + runs5
        score = runs_total + _15s + pairs + self.suits + self.nobs

        if cut_card:
            self.hand.remove(cut_card)
            
            # cut_image = pygame.Surface((65, 99)).convert_alpha()
            # cut_image.blit(cut_card.mini_image, (1, 1))

            card_images = [self.sets_of_run_image, self.sets_of_15_image, self.sets_of_pair_image]
            images_low_to_high = sorted(card_images, key=self.sort_imgs)
            y = images_low_to_high[-1].get_height()
            middle = self.image_middle.copy()
            middle.blit(self.sets_of_run_image, (9, 76))
            middle.blit(self.sets_of_15_image, (211, 76))
            middle.blit(self.sets_of_pair_image, (413, 76))
            
            mid_y = 175 if self.suits or self.nobs else 145
            self.image = pygame.Surface((551, mid_y + y + 90)).convert_alpha()
            self.image.fill((0, 0, 0, 30))
            pygame.draw.rect(self.image, (0, 0, 0, 60), (5, 5, self.image.get_width() - 10, self.image.get_height() - 10))
            
            self.image.blit(self.image_top, (0, 0))
            for index, card in enumerate(self.hand):
                self.image.blit(card.mini_image, (index * 63 + 10, 39))
            self.image.blit(cut_card.mini_image, (274, 39))
            # self.image.blit(cut_image, (274, 39))
            self.image.blit(middle, (0, mid_y), (0, 0, 551, y + 80))
            self.image.blit(self.image_bottom, (0, self.image.get_height() -self.image_bottom.get_height()))

            self.draw_card_title()

            if self.name == 'player':
                self.rect = self.image.get_rect(bottomright = self.pos)
            
            # self.image.blit(hand_image, (10, 39))
            # self.image.blit(cut_image, (274, 39))
            
            total_score_surf = self.get_surf(f'{score}', (448, 86), self.large_font)
            self.image.blit(total_score_surf[0], total_score_surf[1])

            self.draw_text(runs_total, _15s, pairs)

        return score ###############################################################################################################

    def draw_text(self, runs, _15s, pairs):
        y = 195
        if self.suits or self.nobs:
            y += 30
            if self.suits:
                surf = self.get_surf(f'Flush +{self.suits}', (80, 155), self.small_font)
                self.image.blit(surf[0], surf[1])
            if self.nobs:
                if self.suits:
                    surf = self.get_surf(f'Nobs +1', (276, 155), self.small_font)
                else:
                    surf = self.get_surf(f'Nobs +1', (80, 155), self.small_font)
                self.image.blit(surf[0], surf[1])

        if runs:
            surf = self.get_surf(f'+{runs}', (108, y), self.medium_font)
            self.image.blit(surf[0], surf[1])
        if _15s:
            surf = self.get_surf(f'+{_15s}', (308, y), self.medium_font)
            self.image.blit(surf[0], surf[1])
        if pairs:
            surf = self.get_surf(f'+{pairs}', (478, y), self.medium_font)
            self.image.blit(surf[0], surf[1])

    def get_surf(self, text, pos, font):
        shadow = font.render(f'{text}', True, self.shadow_color)
        width = shadow.get_width()
        height = shadow.get_height()
        image = pygame.Surface((width + 2, height)).convert_alpha()
        image.fill((0, 0, 0, 0))
        
        image.blit(shadow, (2, 2))
        img = font.render(f'{text}', True, self.color)
        image.blit(img, (0, 0))
        rect = image.get_rect(center = pos)
        return image, rect

    def get_15s(self): # mini_image size = 63, 97
        images = []
        for index, card in enumerate(self.hand):
            for subset in combinations(self.hand, index + 2):
                if sum([min(card.value, 10) for card in subset]) == 15:
                    images.append(self.get_scoring_surf(subset))
        if images:
            self.sets_of_15_image = pygame.Surface((192, 99 + ((len(images) - 1) * 40))).convert_alpha()
            self.sets_of_15_image.fill((0, 0, 0, 0))
            for index, img in enumerate(images):
                self.sets_of_15_image.blit(img, (0, 1 + index * 40))
        return len(images) * 2

    def get_pairs(self):
        images = []
        for subset in combinations(self.hand, 2):
            if subset[0].value == subset[1].value:
                img = self.get_scoring_surf(subset)
                images.append(img)
        if images:
            self.sets_of_pair_image = pygame.Surface((129, 99 + ((len(images) - 1) * 40))).convert_alpha()
            for index, img in enumerate(images):
                self.sets_of_pair_image.blit(img, (0, index * 40))
        return len(images) * 2

    def get_runs_of_three(self):
        images = []
        for subset in combinations(self.hand, 3):
            if subset[0].value + 1 == subset[1].value and subset[1].value + 1 == subset[2].value:
                img = self.get_scoring_surf(subset)
                images.append(img)
        if images:
            self.sets_of_run_image = pygame.Surface((192, 99 + ((len(images) - 1) * 40))).convert_alpha()
            for index, img in enumerate(images):
                self.sets_of_run_image.blit(img, (0, index * 40))
        return len(images) * 3
                
    def get_runs_of_four(self):
        images = []
        for subset in combinations(self.hand, 4):
            if subset[0].value + 1 == subset[1].value and subset[1].value + 1 == subset[2].value and subset[2].value + 1 == subset[3].value:
                img = self.get_scoring_surf(subset)
                images.append(img)
        if images:
            self.sets_of_run_image = pygame.Surface((192, 99 + (len(images) - 1) * 40)).convert_alpha()
            for index, img in enumerate(images):
                self.sets_of_run_image.blit(img, (0, index * 40))
        return len(images) * 4

    def get_runs_of_five(self):
        v = [card.value for card in self.hand]
        if len(self.hand) < 5:
            return 0
        if v[1] == v[0] + 1 and v[2] == v[0] + 2 and v[3] == v[0] + 3 and v[4] == v[0] + 4:
            img = self.get_scoring_surf(self.hand)
            self.sets_of_run_image = pygame.Surface((189, 1 * 97)).convert_alpha()
            self.sets_of_run_image.blit(img, (0, 0))
            return 5
        return 0

    def get_suits(self):
        # print([card for card in self.hand])
        if all(card.suit == self.hand[0].suit for card in self.hand):
            return 4
        return 0

    def get_nobs(self, cut_card):
        for card in self.hand:
            if card.value == 11 and card.suit == cut_card.suit:
                return 1
        return 0

    def get_scoring_surf(self, subset):
        image = pygame.Surface((189, 97)).convert_alpha()
        if len(subset) == 2:
            image = pygame.Surface((126, 97)).convert_alpha()
        image.fill((0, 0, 0, 0))

        x_step = 63
        if len(subset) == 4:
            x_step = 42
        elif len(subset) == 5:
            x_step = 31
        for index, card in enumerate(subset):
            image.blit(card.mini_image, (index * x_step , 0))
        return image


class FlipCard(pygame.sprite.Sprite):
    def __init__(self, front, back, pos):
        super().__init__()
        self.image = back
        self.back = back
        self.front = front
        self.rect = self.image.get_rect(topleft = pos)
        self.angle = 270
        self.width = 127
        self.angle_step = 7
        self.active = False
        
    def update(self, dt):
        if self.active:
            # print('updating flip')
            self.width = round(math.sin(math.radians(self.angle)) * 127) 
            self.angle += self.angle_step
            if self.angle > 270 + 180:
                self.angle_step = 0
                self.active = False
            rot_image = self.front if self.width >= 0 else self.back
            self.image = pygame.transform.scale(rot_image.copy(), (abs(self.width), self.rect.height))
            # self.image = rot_image
            self.rect = self.image.get_rect(center = self.rect.center)


class Button(pygame.sprite.Sprite):
    def __init__(self, pos, image):
        super().__init__()
        self.image = image
        self.rect = self.image.get_rect(center = pos)


class ScoreSprite(pygame.sprite.Sprite):
    def __init__(self, pos, score, image):
        super().__init__()
        self.image = image.copy()
        self.rect = self.image.get_rect(center = (pos))
        self.pos = pos
        text = small_font.render('+' + str(score), True, 'black')
        text_rect = text.get_rect(center = (18, 20))
        self.image.blit(text, text_rect)
