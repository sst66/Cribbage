
import math
from random import choice, randint
from itertools import combinations
from copy import copy

import pygame, sys
from pygame.math import Vector2


from timer import Timer
from players import Base as Crib, HumanPlayer, CPUPlayer
from support import import_folder, player_dots, CPU_dots
from scorekeeper import Scorekeeper, FlipCard, ScoreSprite, Button

# written using VSCode with Pygame 2.1.2 (SDL 2.0.18) and Python 3.9.5

# open the 'game' folder in VSCode (not the files)
# either right click the 'game' folder and select 'Open with Code'
# or within the VSCode File menu, select 'Open Folder' and browse
# to and select the 'game' folder 

# run 'cribbage.py' from within VSCode or navigate your cmd window to
# the 'game' folder containing the .py files and execute 'cribbage.py'

# Note: be sure the ExternalData folder remains in the Cribbage folder
#       next to the game folder as follows

#       Cribbage
#        /    \
#    game      ExternalData
#     |              |
# .py files      image folders

# This code is free and open source
# Feel free to use/edit/distribute as you see fit
# I will not be responsible for anything it does 
# to anything, use at your own risk


card_sprites = pygame.sprite.Group() # used in game and deck and passed to players
flip_sprites = pygame.sprite.GroupSingle() # game and CutDeck

pygame.font.init()


class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((1220, 780))
        pygame.display.set_caption('Cards')
        cursor_surf = pygame.image.load('../ExternalData/UI/hand_cursor.png').convert_alpha()
        cursor = pygame.cursors.Cursor((10, 1), cursor_surf)
        pygame.mouse.set_cursor(cursor)
        
        self.font = pygame.font.Font('../ExternalData/font/AveriaBold.ttf', 70)


        self.FPSclock = pygame.time.Clock()


        self.scorecard_sprites = pygame.sprite.Group() # game
        self.peg_sprites = pygame.sprite.Group() # game and players
        self.hand_score_sprites = pygame.sprite.Group() # game and passed to players
        self.player_sprites = pygame.sprite.Group() # game and passed to players
        self.button_sprites = pygame.sprite.GroupSingle() # game
        self.gameover_sprites = pygame.sprite.GroupSingle() # game
        self.pegging_score_sprites = pygame.sprite.Group() # game
        self.scorekeeper_sprites = pygame.sprite.GroupSingle() # game
        self.cut_deck_sprites = pygame.sprite.GroupSingle() # game

        
        self.scorekeeper = Scorekeeper()

        self.human_player = HumanPlayer(self.peg_sprites,
                                        'player',               
                                        card_sprites, 
                                        self.player_sprites, 
                                        self.scorekeeper, 
                                        self.hand_score_sprites)

        self.CPU_player = CPUPlayer(self.peg_sprites,
                                    'CPU', 
                                    card_sprites, 
                                    self.scorekeeper, 
                                    self.hand_score_sprites)

        self.crib_player = Crib('crib', card_sprites, self.hand_score_sprites)

        self.scorekeeper_sprites.add(self.scorekeeper)
        self.human_player.update_total_score()
        self.CPU_player.update_total_score()
        
        
        self.show_scorecard_buttons = pygame.sprite.Group() # game
        self.show_scorecard_buttons.add(self.human_player.show_scorecard_button, self.CPU_player.show_scorecard_button, self.crib_player.show_scorecard_button)

        self.deck = Deck((84, 282))
        self.BG = pygame.image.load('../ExternalData/UI/BG2.png').convert_alpha()
        self.deck_image = pygame.image.load('../ExternalData/UI/deck2.png').convert_alpha()
        self.deck_rect = self.deck_image.get_rect(topleft = (69, 296))
        self.peg_score_image = pygame.image.load('../ExternalData/UI/pegging_sprite.png')

        self.cut_deck = CutDeck((77, 288), self.deck.cards[1].front, self.deck.cards[1].back)

        # h = [19, 16, 18, 41, 17]
        # self.human_player.hand = [copy(self.deck.cards[h[0]]), 
        #                         copy(self.deck.cards[h[1]]), 
        #                         copy(self.deck.cards[h[2]]), 
        #                         copy(self.deck.cards[h[3]])]
        # self.human_player.update_scorecard_and_get_score(self.deck.cards[h[4]])
        # self.human_player.score_four(self.human_player.hand)

        imgs = import_folder('../ExternalData/buttons/')
        self.buttons = {'add': Button(self.human_player.hand_pos + Vector2(164, 98), imgs[0]), 
                    'cut': Button(self.human_player.hand_pos + Vector2(164, 98), imgs[1]), 
                    'deal': Button(self.human_player.hand_pos + Vector2(164, 98), imgs[2]), 
                    'discard': Button(self.human_player.hand_pos + Vector2(164, 98), imgs[3]), 
                    'play': Button(self.human_player.hand_pos + Vector2(164, -138), imgs[4])}
        
        self.running_count = 0
        self.update_count_surf()
        self.mouse_pos = None
        self.cards_played_pos_x = 396
        self.show_non_dealer_score = False
        self.show_dealer_score = False
        self.show_crib_score = False
        self.flipping = False
        self.cut_card = None

        self.state = 'spread_cards'
        self.init_state = True
        self.states = {'spread_cards': self.spread_cards, 
                        'cut_for_deal': self.cut_for_deal, 
                        'dealing': self.dealing, 
                        'discarding': self.discarding, 
                        'pegging': self.pegging, 
                        'add_non_dealer_score': self.add_non_dealer_score,
                        'add_dealer_score': self.add_dealer_score, 
                        'endgame': self.endgame}

    def draw_screen(self):
        self.screen.blit(self.BG, (0, 0))

        self.screen.blit(self.count_surf, self.count_surf_rect)
        
        self.scorekeeper_sprites.draw(self.screen)
        
        if self.state != 'cut_for_deal' and self.state != 'spread_cards':
            self.screen.blit(self.deck_image, self.deck_rect)

        self.cut_deck_sprites.update(self.dt)
        self.cut_deck_sprites.draw(self.screen)

        card_sprites.update(self.dt)
        card_sprites.draw(self.screen)

        self.peg_sprites.update(self.dt)
        self.peg_sprites.draw(self.screen)

        flip_sprites.update(self.dt)
        flip_sprites.draw(self.screen)

        self.pegging_score_sprites.draw(self.screen)
        
        self.hand_score_sprites.draw(self.screen)

        self.scorecard_sprites.draw(self.screen)
        self.show_scorecard_buttons.draw(self.screen)

        self.gameover_sprites.draw(self.screen)
        self.button_sprites.draw(self.screen)


        pygame.display.update()

    def run(self):
        self.ticks = pygame.time.get_ticks()
        while True:
            self.dt = (pygame.time.get_ticks() - self.ticks)
            self.ticks = pygame.time.get_ticks()
            self.mouse_pos = self.get_events()
            pygame.display.set_caption(str(self.dt))

            self.draw_screen()
            # self.FPSclock.tick(60)

            if self.mouse_pos:
                player = self.get_score_button_clicks(self.mouse_pos)
                if player:
                    if player.scorecard not in self.scorecard_sprites:
                        self.scorecard_sprites.add(player.scorecard)
                    else:
                        self.scorecard_sprites.remove(player.scorecard)

            self.states[self.state]()
            
    def get_events(self): # returns mouse position if LMB was clicked, None if not
        pos = None
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1:
                    pos = pygame.mouse.get_pos()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    if self.human_player.add_score(11):
                        self.state = 'endgame'
                        self.init_state = True

                elif event.key == pygame.K_RIGHT:
                    if self.CPU_player.add_score(20):
                        self.state = 'endgame'
                        self.init_state = True
                elif event.key == pygame.K_DOWN:
                    self.deck.shuffle()
                    flip_sprites.empty()
                    self.cut_deck.active = True
                elif event.key == pygame.K_UP:
                    self.scorecard_sprites.empty()
        return pos
        
    def score_pegging(self, seq):
        if len(seq) < 2:
            return
        runUps = 0
        runDowns = 0
        continue_pair = True
        top_card = seq[-1].value
        pairs = 0
        continue_run = True
        pair_scores = [0, 2, 6, 12]
        score = 0
        if self.running_count == 15:
            score += 2

        if self.running_count == 31:
            score += 2

        for i in range(len(seq) - 2, -1, -1):
            if continue_pair:
                if seq[i].value == top_card:
                    pairs += 1
                else:
                    continue_pair = False
                    
            if continue_run:
                if seq[i].value == top_card - 1 - runDowns:
                    runDowns += 1
                elif seq[i].value == top_card + 1 + runUps:
                    runUps += 1
                else:
                    continue_run = False
        score_for_pairs = pair_scores[pairs]
        score_for_runs = runUps + runDowns + 1
        if score_for_runs > 2:
            score += score_for_runs
        score += score_for_pairs
        return score
        
    def get_score_button_clicks(self, mouse_pos): # returns name of player whose score button was clicked , None if not
        for player in [self.human_player, self.CPU_player, self.crib_player]:
            if player.show_scorecard_button.rect.collidepoint(mouse_pos):
                # print(player.name, 'yes')
                return player
        return None

    def is_score_there(self, pos): # used to prevent stacking pegging score sprites atop each other
        for sprite in self.pegging_score_sprites.sprites():
            if sprite.pos == pos:
                return True
        return False
        
    def update_count_surf(self):
        img = self.font.render(f'{self.running_count}', True, 'navajowhite3')
        shadow = self.font.render(f'{self.running_count}', True, 'black')
        new_image = pygame.Surface((shadow.get_width(), shadow.get_height())).convert_alpha()
        new_image.fill((0, 0, 0, 0))
        new_image.blit(shadow, (3, 3))
        new_image.blit(img, (0, 0))
        self.count_surf = new_image
        self.count_surf_rect = new_image.get_rect(center = (920, 380))
                                                                                    ###############################################
                                                                                    ##############   start of states   ############
                                                                                    ###############################################
                                                                            
                                                                                        ###########################################
                                                                                        ###########   spread cards    #############
                                                                                        ###########################################

    def cards_are_moving(self):
        if any([card.active for card in card_sprites.sprites()]):
            # print('cards active, returning from ', self.state)
            return True
        return False

    def spread_cards(self): # main loop state
        if self.init_state:
            self.init_state = False
            self.button_sprites.add(self.buttons['cut'])
            self.cards_spreading = False
            self.retry = False
            self.deck.shuffle()
            self.deck.stack_52_cards()
            for card in self.deck.cards:
                card.image = card.back
            card_sprites.empty()
            for card in self.deck.cards:
                card_sprites.add(card)

        if self.mouse_pos:
            if self.button_sprites:
                if self.button_sprites.sprite.rect.collidepoint(self.mouse_pos): # spread the cards
                    self.button_sprites.empty()
                    for index, card in enumerate(card_sprites.sprites()):
                        waypoint = Vector2(card.rect.topleft[0] + index * 13, self.deck.pos.y)
                        self.deck.send_card_to(card, waypoint)
                    self.cards_spreading = True
        if self.cards_spreading:
            if not card_sprites.sprites()[-1].active:
                self.state = 'cut_for_deal'
                self.init_state = True
                                                                                        ###########################################
                                                                                        ###########   cut for deal    #############
                                                                                        ###########################################

    def cut_for_deal(self):
        if self.init_state:
            if self.cards_are_moving():
                return
            self.init_state = False
            self.CPU_cut_card = choice(self.deck.cards)
            self.CPU_cut_card.image = self.CPU_cut_card.front
            self.CPU_cut_card.waypoint = Vector2(236, 22)
            self.CPU_cut_card.movement_speed = 3
            self.CPU_cut_card.active = True
            self.cards_spreading = False
            self.deck.shuffle()

        if self.retry and not card_sprites.sprites()[-1].active:
            if not self.cards_spreading:
                self.cards_spreading = True
                for index, card in enumerate(card_sprites.sprites()):
                    card.image = card.back
                    waypoint = Vector2(card.rect.topleft[0] + index * 13, self.deck.pos.y)
                    self.deck.send_card_to(card, waypoint)
            if not card_sprites.sprites()[-1].active:
                self.retry = False
                self.init_state = True
            return

        if self.mouse_pos:
            if self.button_sprites:
                if self.button_sprites.sprite.rect.collidepoint(self.mouse_pos):

                    if self.button_sprites.sprite is self.buttons['deal']:
                        self.state = 'dealing'
                        self.init_state = True
                        self.deck.stack_52_cards()
                    else: # cards matched
                        self.deck.stack_52_cards()
                        self.retry = True
                    self.button_sprites.empty()
            overlap_sprites = [card for card in card_sprites if card.rect.collidepoint(self.mouse_pos)]
            if overlap_sprites:
                card = overlap_sprites.pop()
                if card is not self.CPU_cut_card:
                    card.image = card.front
                    card.waypoint = Vector2(236, 562)
                    card.movement_speed = 3
                    card.active = True
                    if card.value == self.CPU_cut_card.value:
                        self.button_sprites.add(self.buttons['cut'])
                    else:
                        self.button_sprites.add(self.buttons['deal'])
                        self.human_player.is_dealer = True if self.CPU_cut_card.value < card.value else False
                                                                                        ##############################################
                                                                                        ##############   dealing         ############
                                                                                        ##############################################

    def dealing(self):
        if self.init_state:
            if self.cards_are_moving():
                return
            self.init_state = False
            # dealer is index 1 in this list
            self.players = [self.CPU_player, self.human_player] if self.human_player.is_dealer else [self.human_player, self.CPU_player]
            self.crib_player.hand_pos = Vector2(36, self.players[1].hand_pos.y)
            
            self.show_non_dealer_score = False
            self.show_dealer_score = False
            self.show_crib_score = False
            self.player_sprites.empty()
            self.human_player.hand = []
            self.CPU_player.hand = []
            self.deck.shuffle()
            card_sprites.empty()
            self.cut_deck_sprites.add(self.cut_deck)
            self.deck.get_12_cards()
            self.cards_dealt = 0
            
            flip_sprites.empty()
            
            self.running_count = 0
            self.player_index = 0
            self.update_count_surf()
            self.human_player.is_dealer = not self.human_player.is_dealer

        if all([card.movement_speed < .5 for card in card_sprites.sprites()]):
            if self.cards_dealt < 12:
                card = self.deck.draw_card()
                card_sprites.remove(card)
                card_sprites.add(card)
                self.cards_dealt += 1
                waypoint = self.players[self.player_index].hand_pos + Vector2(len(self.players[self.player_index].hand) * 40, 0)
                self.players[self.player_index].hand.append(card)
                if self.players[self.player_index] is self.human_player:
                    card.flip = True
                    self.player_sprites.add(card)
                self.deck.send_card_to(card, waypoint)
                self.player_index += 1
                self.player_index = self.player_index % 2
            else:
                self.state = 'discarding'
                self.init_state = True
                                                                                        ##############################################
                                                                                        ##############   discarding       ############
                                                                                        ##############################################

    def discarding(self):
        if self.init_state:
            self.init_state = False
            self.human_player.discards = []
            self.CPU_player.discards = []

            self.CPU_player.choose_discards()

            self.CPU_player.send_discards_to_crib(self.crib_player.hand_pos)
            self.CPU_player.sort_cards()
            self.human_player.sort_cards()
            for card in self.human_player.hand:
                self.player_sprites.remove(card)
                self.player_sprites.add(card)


        if self.cards_are_moving():
            return

        if self.mouse_pos:
            if self.button_sprites and self.button_sprites.sprite.rect.collidepoint(self.mouse_pos): # discard button
                self.button_sprites.empty()
                self.cut_card = self.deck.cards[14]
                if self.cut_card.value == 11:
                    if self.players[1].add_score(2):
                        self.state = 'endgame'
                        self.init_state = True
                self.cut_deck.front = self.cut_card.front
                self.cut_deck.active = True
                self.cut_deck_sprites.add(self.cut_deck)
                
                self.human_player.send_discards_to_crib(self.crib_player.hand_pos + Vector2(60, 0))
                self.human_player.arrange_cards()
                self.human_player.hand_score = self.human_player.update_scorecard_and_get_score(self.cut_card)

                self.CPU_player.hand_score = self.CPU_player.update_scorecard_and_get_score(self.cut_card)

                self.crib_player.hand = self.human_player.discards + self.CPU_player.discards
                self.crib_player.arrange_cards()
                self.crib_player.hand_score = self.crib_player.update_scorecard_and_get_score(self.cut_card)

                self.human_player.update_hand_score()
                self.CPU_player.update_hand_score()
                self.crib_player.update_hand_score()

                for card in self.CPU_player.hand:
                    card.active = False
                self.state = 'pegging'
                self.init_state = True
            else:
                if self.cards_are_moving():
                    return
                overlap_sprites = [card for card in self.player_sprites if card.rect.collidepoint(self.mouse_pos)]
                if overlap_sprites:
                    card = overlap_sprites.pop()
                    if card not in self.human_player.discards:
                        if len(self.human_player.discards) < 2:
                            card.rect.top -= 20
                            card.pos.y = round(card.rect.top)
                            self.human_player.discards.append(card)
                    else:
                        card.rect.top += 20
                        card.pos.y = round(card.rect.top)
                        self.human_player.discards.remove(card)
                    if len(self.human_player.discards) == 2:
                        self.button_sprites.add(self.buttons['discard'])
                    else:
                        self.button_sprites.empty()
                                                                                        ##############################################
                                                                                        ##############   play inning      ############
                                                                                        ##############################################

    def pegging(self):
        if self.init_state:
            if self.cards_are_moving():
                return
            print(self.human_player.get_score(self.cut_card), '#######################################')
            self.init_state = False
            self.hands = {self.human_player: self.human_player.hand, self.CPU_player: self.CPU_player.hand}
            self.game_players = [self.human_player, self.CPU_player]
            self.active_players = [self.players[0], self.players[1]]
            self.table = []
            self.seq = []
            self.x_offset = self.cards_played_pos_x
        
        if self.active_players:
            
            player = self.active_players[0]
            # if player.old_score_peg.active:
            #     return
            if any([peg.active for peg in player.pegs]):
                return

            if self.active_players[0] is self.human_player:
                if self.mouse_pos:
                    overlap_sprites = [card for card in self.player_sprites if card.rect.collidepoint(self.mouse_pos)]
                    if overlap_sprites:
                        card = overlap_sprites.pop()
                        if self.running_count + min(card.value, 10) > 31:
                            if any([min(c.value, 10) + self.running_count < 32 for c in player.hand]):
                                print('try playing a lower card')
                            else:
                                self.active_players.remove(player)
                            return
                    else:
                        return
                else:
                    return

            else:
                card = self.CPU_player.get_CPU_card(self.seq, self.running_count)
                if card is None:
                    self.active_players.remove(self.CPU_player)
                    return

            # we got a card
            self.hands[player].remove(card)

            if card in self.player_sprites:
                self.player_sprites.remove(card)
            player.arrange_cards()

            card_sprites.remove(card)
            card_sprites.add(card)

            waypoint = Vector2(self.x_offset, player.cards_played_pos_y)
            self.deck.send_card_to(card, waypoint)

            self.x_offset += 30
            self.running_count += min(card.value, 10)
            self.update_count_surf()
            
            self.table.append({'player': player, 'card': card})
            self.seq.append(card)
                
            score = self.score_pegging(self.seq)
            if score:
                pos = Vector2(self.x_offset + player.peg_score_pos[0], player.peg_score_pos[1])
                if self.is_score_there([pos]):
                    pos += Vector2(0, 30)
                self.pegging_score_sprites.add(ScoreSprite(pos, score, self.peg_score_image))
                if player.add_score(score):
                    self.state = 'endgame'
                    self.init_state = True
                
            if self.running_count == 31:
                self.active_players = []
                return
                
            if not self.hands[player]:
                self.active_players.remove(player)

            if len(self.active_players) == 2:
                self.active_players[0], self.active_players[1] = self.active_players[1], self.active_players[0]

        else:

            player_of_last_card = self.table[-1]['player']
            # print(f'both players said go and {player_of_last_card.name} played last')
            self.active_players = [p for p in self.game_players if p != player_of_last_card and self.hands[p]]

            if self.hands[player_of_last_card]:
                self.active_players += [player_of_last_card]

            # print(f'players after this round {[p.name for p in self.active_players]}')

            if self.running_count < 31:

                if player_of_last_card.add_score(1):
                    print('adding go')
                    self.state = 'endgame'
                    self.init_state = True
                pos = Vector2(self.x_offset + player_of_last_card.peg_score_pos[0], player_of_last_card.peg_score_pos[1])
                if self.is_score_there(pos):
                    pos += Vector2(0, 30)
                self.pegging_score_sprites.add(ScoreSprite(pos, 1, self.peg_score_image))
                
            if self.CPU_player.hand or self.human_player.hand:
                self.pegging_index = len(self.table)
                self.running_count = 0
                self.update_count_surf()
                self.seq = []
            else:
                self.state = 'add_non_dealer_score'
                self.init_state = True
                                                                                        ##############################################
                                                                                        ##############   add non dealer score     ####
                                                                                        ##############################################

    def add_non_dealer_score(self):
        if self.init_state:
            if any([peg.active for peg in self.peg_sprites.sprites()]):
                return
            self.init_state = False
            if self.players[0].hand_score > 0:
                print('adding score in non dealer')
                if self.players[0].add_score(self.players[0].hand_score):
                    self.state = 'endgame'
                    self.init_state = True
            self.hand_score_sprites.add(self.players[0].hand_score_sprite)

            for card in self.crib_player.hand:
                card.image = card.front

            self.show_non_dealer_score = True
            self.dealer_score_added = False
            self.crib_score_added = False
            self.button_sprites.add(self.buttons['add'])
            
        if self.mouse_pos:
            if self.button_sprites:
                if self.button_sprites.sprite.rect.collidepoint(self.mouse_pos):
                    self.button_sprites.empty()
        
                    self.state = 'add_dealer_score'
                    self.init_state = True
                                                                                        ##############################################
                                                                                        ##############   add dealer score     ########
                                                                                        ##############################################

    def add_dealer_score(self):
        if self.init_state:
            if any([peg.active for peg in self.peg_sprites.sprites()]):
                return
            self.init_state = False
            self.show_dealer_score = True
            if self.players[1].hand_score > 0:
                if self.players[1].add_score(self.players[1].hand_score):
                    self.state = 'endgame'
                    self.init_state = True
            self.hand_score_sprites.add(self.players[1].hand_score_sprite)
            self.hand_score_sprites.add(self.crib_player.hand_score_sprite)
            self.show_dealer_score = True
            self.crib_added = False
            
        if any([peg.active for peg in self.peg_sprites.sprites()]):
            return
        if not self.crib_added:
            self.show_crib_score = True
            self.crib_added = True
            if self.crib_player.hand_score > 0:
                if self.players[1].add_score(self.crib_player.hand_score):
                    self.state = 'endgame'
                    self.init_state = True
            self.button_sprites.add(self.buttons['deal'])
        if self.mouse_pos:
            if self.button_sprites:
                if self.button_sprites.sprite.rect.collidepoint(self.mouse_pos):
                    
                    self.button_sprites.empty()
                    
                    self.pegging_score_sprites.empty()

                    self.hand_score_sprites.empty()

                    self.deck.stack_12_cards()
                    flipcard = FlipCard(self.cut_card.back, self.cut_card.front, self.deck.pos)
                    flipcard.active = True
                    flip_sprites.add(flipcard)

                    self.state = 'dealing'
                    self.init_state = True
                                                                                    #################################
                                                                                    ########   endgame   ############
                                                                                    #################################

    def endgame(self):
        if self.init_state:
            if any([peg.active for peg in self.peg_sprites.sprites()]):
                return
            for card in card_sprites:
                card.image = card.front
            self.init_state = False
            self.button_sprites.empty()
            self.button_sprites.add(self.buttons['play'])
            if self.human_player.score == 121:
                self.gameover_sprites.add(self.human_player.gameover_sprite)
            else:
                self.gameover_sprites.add(self.CPU_player.gameover_sprite)

        if self.mouse_pos:
            if self.button_sprites:
                if self.button_sprites.sprite.rect.collidepoint(self.mouse_pos):
                    
                    self.button_sprites.empty()
                    self.gameover_sprites.empty()
                    self.hand_score_sprites.empty()
                    self.pegging_score_sprites.empty()

                    self.deck.stack_12_cards()
                    if self.cut_card:
                        flipcard = FlipCard(self.cut_card.back, self.cut_card.front, self.deck.pos)
                        flipcard.active = True
                        flip_sprites.add(flipcard)

                    self.human_player.reset_score() # and pegs
                    self.CPU_player.reset_score()

                    self.state = 'dealing'
                    self.init_state = True
                                                                            ###########################################################################
                                                                            #########################    end of states     ############################
                                                                            ###########################################################################


    ######################################################################################################################################
    #######################################################   end of game class   ########################################################
    ######################################################################################################################################


class CutDeck(pygame.sprite.Sprite):
    def __init__(self, pos, front, back):
        super().__init__()
        self.image = pygame.image.load('../ExternalData/UI/deck2.png').convert_alpha()
        self.rect = self.image.get_rect(topleft = pos)

        self.front = front
        self.back = back
        self.pos = Vector2(pos)
        self.active = False
        self.movement_speed = .5
        self.direction = Vector2(1, 0)
        self.home_x = 76
        self.cut_timer = Timer(500)



    def update(self, dt):
        if self.active:
            if self.cut_timer.active:
                self.cut_timer.update(dt)
                return
            if self.movement_speed > 0:
                if self.pos.x < 225:
                    self.pos += self.direction * self.movement_speed * dt
                    self.rect.top = round(self.pos.y)
                    self.rect.left = round(self.pos.x)
                else:
                    self.cut_timer.activate()
                    card = FlipCard(self.front, self.back, self.pos - Vector2(150, -8))
                    card.active = True
                    flip_sprites.add(card)
                    self.movement_speed *= -1
            else:
                if self.pos.x > 76:
                    self.pos += self.direction * self.movement_speed * dt
                    self.rect.top = round(self.pos.y)
                    self.rect.left = round(self.pos.x)
                else:
                    self.pos.x = self.home_x
                    self.rect.left = self.home_x
                    self.active = False
                    self.movement_speed = .5


class Deck:
    def __init__(self, pos): # NOT HERE!!!!!!!!!!!!!!!!!!!!!!!!!!!
        self.pos = Vector2(pos)
        self.cards = []
        self.crib = []
        self.cut_card = None

        card_images = import_folder('../ExternalData/cards/')
        card_back_image = pygame.image.load('../ExternalData/card_backs/004.png').convert_alpha()
        for value in range(13):
            for suit in range(4):
                card = Card(card_images[value * 4 + suit], card_back_image, value + 1, suit, self.pos)
                card.image = card.back
                card_sprites.add(card)
                self.cards.append(card)
        
    def __len__(self):
        return len(self.cards)

    def stack_52_cards(self):
        for index, card in enumerate(card_sprites.sprites()[::-1]):
            waypoint = self.pos - Vector2(index // 3,  -index // 3)
            card.image = card.back
            self.send_card_to(card, waypoint)

    def send_card_to(self, card, target):
        card.waypoint = target
        card.movement_speed = 3
        card.active = True
    
    def shuffle(self):
        for i in range(len(self.cards) - 1, 0, -1):
            r = randint(0, i)
            self.cards[i], self.cards[r] = self.cards[r], self.cards[i]
            self.cards[i].rect, self.cards[r].rect = self.cards[r].rect, self.cards[i].rect
            self.cards[i].pos = Vector2(self.cards[i].rect.topleft)
            self.cards[r].pos = Vector2(self.cards[r].rect.topleft)
        card_sprites.empty()
        for card in self.cards:
            card_sprites.add(card)

    def get_12_cards(self):
        self.copied_cards = [copy(card) for card in self.cards[40:]]
        for index, card in enumerate(self.copied_cards):
            card_sprites.add(card)

    def stack_12_cards(self):
        for index, card in enumerate(card_sprites.sprites()):
            waypoint = (self.pos[0] + index // 2, self.pos[1] + 5 - index // 2)
            card.image = card.front
            card.flip = False
            self.send_card_to(card, waypoint)
        for card in card_sprites:
            card.image = card.back

    def draw_card(self):
        card = self.copied_cards.pop()
        return card

    ######################################################################################################################################
    #######################################################   end of Deck class     ######################################################
    ######################################################################################################################################

                
class Card(pygame.sprite.Sprite):
    def __init__(self, img, card_back_image, value, suit, pos):
        super().__init__()
        # image
        self.front = img
        self.back = card_back_image
        self.image = self.front
        self.value = value
        self.suit = suit
        
        # movement
        self.pos = Vector2(pos)
        self.rect = self.image.get_rect(topleft = pos)
        self.waypoint = Vector2()
        self.direction = Vector2()
        self.movement_speed = 3
        self.active = False
        self.flip = False
        self.mini_image = pygame.transform.rotozoom(self.front.copy(), 0, .5).convert_alpha()
        values = ['Ace', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Jack', 'Queen', 'King']
        suits = ['clubs', 'diamonds', 'hearts', 'spades']
        self.name = values[self.value - 1] + ' of ' + suits[self.suit]

    def __add__(self, other):
        return min(10, self.value) + min(10, other.value)

    def __str__(self):
        values = ['Ace', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Jack', 'Queen', 'King']
        suits = ['clubs', 'diamonds', 'hearts', 'spades']
        return f'{values[self.value - 1]} of {suits[self.suit]}'

    def update(self, dt):
        if self.active:
            self.direction = self.waypoint - self.pos
            if self.direction.length() > 0:
                self.direction.normalize_ip()
            self.pos += self.direction * self.movement_speed * dt
            self.rect.topleft = (round(self.pos.x), round(self.pos.y))
            dist = (self.pos - self.waypoint).length()
            if dist < 200:
                self.movement_speed = dist * .01
                if dist < 1:
                    self.pos = Vector2(self.rect.topleft)
                    self.active = False
                    self.movement_speed = 0
                if self.flip:
                    self.image = self.front
                
    ######################################################################################################################################
    ######################################################   end of card class    ########################################################
    ######################################################################################################################################




            
if __name__ == '__main__':
    game = Game()
    game.run()