
import pygame
from pygame.math import Vector2

import copy
from itertools import combinations
from random import choice

from scorekeeper import ScoreCard
from support import player_dots, CPU_dots

# written using VSCode with Pygame 2.1.2 (SDL 2.0.18) and Python 3.9.5

# open the 'game' folder in VSCode (not the files). 
# either right click the 'game' folder and select 'Open with Code'
# or within the VSCode File menu, select 'Open Folder' and browse
# to and select the 'game' folder 

# run 'cribbage.py' from within VSCode or navigate your cmd window to
# the 'game' folder containing the .py files and execute 'cribbage.py'

# Note: be sure the ExternalData folder remains in the Cribbage folder
# next to the game folder as follows

#       Cribbage
#        /    \
#    game      ExternalData
#     |              |
# .py files      image folders

# This code is free and open source
# Feel free to use/edit/distribute as you see fit
# I will not be responsible for anything it does 
# to anything, use at your own risk

pygame.font.init()
small_font = pygame.font.Font('../ExternalData/font/AveriaBold.ttf', 20)
medium_font = pygame.font.Font('../ExternalData/font/AveriaBold.ttf', 50)

class Base: # inherited by Player
    def __init__(self, name, card_sprites, hand_score_sprites):
        self.name = name
        self.card_sprites = card_sprites
        self.hand_score_sprites = hand_score_sprites

        # the following attributes are overridden in HumanPlayer and CPUPlayer 
        # but they're necessary here for the fake crib player used for scoring the crib
        self.scorecard = ScoreCard((0, 100), self.name)
        self.hand = []
        self.hand_score = 0
        self.hand_pos = Vector2()

        self.hand_score_pos = (300, self.hand_pos.y + 50)
        self.hand_score_sprite = pygame.sprite.Sprite()
        self.hand_score_sprite.image, self.hand_score_sprite.rect = self.get_surf(f'+{self.hand_score}', self.hand_pos + Vector2(250, 80), medium_font, False)
        self.hand_score_pos_offset = Vector2(240, 65)

        self.show_scorecard_button = pygame.sprite.Sprite()
        self.show_scorecard_button.image = pygame.image.load('../ExternalData/UI/CRIB_score.png').convert_alpha()
        self.show_scorecard_button.rect = self.show_scorecard_button.image.get_rect(topleft = (0, 300))

    def update_hand_score(self):
        surf = self.get_surf(f'+{self.hand_score}', self.hand_pos + self.hand_score_pos_offset, medium_font, False)
        self.hand_score_sprite.image = surf[0]
        self.hand_score_sprite.rect = surf[1]

    def get_surf(self, text, pos, font, center):
        shadow = font.render(f'{text}', True, 'black')
        width = shadow.get_width()
        image = pygame.Surface((width + 2, 50)).convert_alpha()
        image.fill((0, 0, 0, 0))
        
        image.blit(shadow, (2, 2))
        img = font.render(f'{text}', True, 'antiquewhite')
        image.blit(img, (0, 0))
        if center:
            rect = image.get_rect(center = pos)
        else:
            rect = image.get_rect(topleft = pos)
        return image, rect
        
    def update_scorecard_and_get_score(self, cut_card): # inherited by BasePlayer
        return self.scorecard.get_score(self.hand, cut_card)
        
    def arrange_cards(self): # specific to Base, inherited by BasePlayer but overridden in HumanPlayer and CPUPlayer
        for index, card in enumerate(self.hand[::-1]):
            waypoint = Vector2(self.hand_pos.x + index * 30, self.hand_pos.y)
            if card.rect.center != waypoint:
                card.waypoint = waypoint
                card.movement_speed = 3
                card.active = True
                self.card_sprites.remove(card)
                self.card_sprites.add(card)


class Player(Base): # inherited by HumanPlayer and CPUPlayer
    def __init__(self, peg_sprites, player_name, card_sprites, scorekeeper, hand_score_sprites):
        super().__init__(player_name, card_sprites, hand_score_sprites)
        
        # general attributes, used by both human and CPU players
        self.old_score = 0
        self.score = 0
        self.wins = 0
        self.waypoints = []
        self.discards = []
        self.score_surf = pygame.Surface((0, 0))
        self.score_list = []
        self.scorekeeper = scorekeeper
        self.peg_sprites = peg_sprites

    def reset_score(self): # and pegs
        self.score = 0
        self.old_score = 122
        self.update_total_score()
        self.old_score_peg.waypoints = [self.dots[122]]
        self.old_score_peg.is_resetting = True
        self.old_score_peg.active = True
        self.score_peg.waypoints = [self.dots[0]]
        self.score_peg.is_resetting = True
        self.score_peg.active = True

    def send_discards_to_crib(self, crib_pos):
            x = crib_pos.x
            for index, card in enumerate(self.discards):
                card.image = card.back
                card.flip = False
                self.hand.remove(card)
                card.waypoint = Vector2(x + index * 30, crib_pos.y)
                card.movement_speed = 3
                card.active = True
    
    def update_total_score(self): # total score is shown at the end of each round
        rect = (self.total_score_pos[0] - 17, self.total_score_pos[1] - 25, 40, 25)
        pygame.draw.rect(self.scorekeeper.image, (0, 0, 0, 0), rect)
        score_surf = self.get_surf(f'{self.score}', self.total_score_pos, small_font, True)
        self.scorekeeper.image.blit(score_surf[0], score_surf[1])
        
        rect = (self.total_wins_pos[0] - 17, self.total_wins_pos[1] - 25, 40, 24)
        pygame.draw.rect(self.scorekeeper.image, (0, 0, 0, 0), rect)
        wins_surf = self.get_surf(f'{self.wins}', self.total_wins_pos, small_font, True)
        self.scorekeeper.image.blit(wins_surf[0], wins_surf[1])

    def add_score(self, score): # increments score and activates pegs
        if self.score_peg.active or self.old_score_peg.active:
            print('TRIED TO ADD SCORE WHEN PEG(S) ARE ACTIVE IN BASE PLAYER!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
            # return
        self.score_list.append(score)
        self.waypoints = self.dots[self.old_score % 122:min(self.score + score + 1, 122)]
        self.old_score_peg.waypoints = self.waypoints
        self.old_score_peg.target = self.waypoints[-1]
        self.old_score_peg.active = True
        self.old_score_peg, self.score_peg = self.score_peg, self.old_score_peg
        self.old_score = self.score
        self.score += score
        self.score = min(self.score, 121)
        if self.score == 121:
            self.wins += 1
            return True
        return False

    def sort_c(self, card): # card sorting key
        return card.value

    def sort_cards(self): # hand needs sorting once, but arrange cards is called for every card played
        self.hand = sorted(self.hand, key=self.sort_c)
        self.arrange_cards()

    def arrange_cards(self): # arranges CPU and human cards to dynamically position them within each hand area
        offset = self.hand_pos.x + 96
        multiplier = 0
        if len(self.hand) == 2: 
            offset = self.hand_pos.x + 40 
            multiplier = 127
        elif len(self.hand) == 3: 
            offset = self.hand_pos.x + 0
            multiplier = 100
        elif len(self.hand) == 4: 
            offset = self.hand_pos.x
            multiplier = 66.5 
        elif len(self.hand) == 6: 
            offset = self.hand_pos.x
            multiplier = 40

        for index, card in enumerate(self.hand):
            waypoint = Vector2(offset + index * multiplier, self.hand_pos.y)
            if card.rect.center != waypoint:
                card.waypoint = Vector2(offset + index * multiplier, self.hand_pos.y)
                card.movement_speed = 3
                card.active = True
                self.card_sprites.remove(card)
                self.card_sprites.add(card)
        for card in self.hand:
            self.card_sprites.remove(card)
            self.card_sprites.add(card)

    def get_score(self, cut_card): # called after discarding, returns score for hand including cut card
        hand_copy = [copy.copy(card) for card in self.hand]
        hand_copy.append(cut_card)
        hand_copy = sorted(hand_copy, key=self.sort_c)
        score = 0
        runs5 = False
        runs4 = False
        suits4 = False
        for index, card in enumerate(hand_copy): # 15s
            for subset in combinations(hand_copy, index + 2):
                if sum([min(card.value, 10) for card in subset]) == 15:
                    score += 2
                    
        for subset in combinations(hand_copy, 2): # pairs, needs cut card, order doesn't matter
            if subset[0].value == subset[1].value:
                score += 2
        
        v = [card.value for card in hand_copy] # run of 5, needs cut card, order DOES matter
        if v[1] == v[0] + 1 and v[2] == v[0] + 2 and v[3] == v[0] + 3 and v[4] == v[0] + 4:
            score += 5
            runs5 = True

        if not runs5: # runs of 4 only count if there's not a run of 5, needs cut card, order DOES matter
            for subset in combinations(hand_copy, 4): # runs of 4
                if subset[0].value + 1 == subset[1].value and subset[1].value + 1 == subset[2].value and subset[2].value + 1 == subset[3].value:
                    score += 4
                    runs4 = True

        if not runs5 and not runs4: # runs of 3 only count if there are no runs of 4 or 5, needs cut card, order DOES matter
            for subset in combinations(hand_copy, 3): # run of 3
                if subset[0].value + 1 == subset[1].value and subset[1].value + 1 == subset[2].value:
                    score += 3
                
        if all([card.suit == self.hand[0].suit for card in self.hand]): # suits 4, doesn't need cut card
            score += 4
            suits4 = True
        
        if suits4: # suits 5 only count if there is suits 4, needs cut card, order doesn't matter
            if cut_card.suit == hand_copy[0].suit:
                score += 1
            
        for card in self.hand: # nobs
            if card.value == 11 and card.suit == cut_card.suit:
                score += 1

        return score


class HumanPlayer(Player):
    def __init__(self, peg_sprites, player_name, card_sprites, player_sprites, scorekeeper, hand_score_sprites):
        super().__init__(peg_sprites, player_name, card_sprites, scorekeeper, hand_score_sprites)

        self.player_sprites = player_sprites
        self.is_dealer = False
        
        self.dots = player_dots

        self.total_score_pos = (127, 97) # scorekeeper local coords, not screen
        self.total_wins_pos = (200, 97)
        self.peg_score_pos = (0, 513) # screen coords
        self.hand_pos = Vector2(410, 542) # screen coords
        self.cards_played_pos_y = 317


        self.scorecard = ScoreCard((1220, 780), self.name) # screen coords
        
        image = pygame.image.load('../ExternalData/pegs/peg_red.png').convert_alpha()
        self.show_scorecard_button.image = pygame.image.load('../ExternalData/UI/YOUR_score.png').convert_alpha()
        self.show_scorecard_button.rect = self.show_scorecard_button.image.get_rect(midbottom = (566, 780))
        
        self.score_peg = Peg(self.dots[0], 0, self, image) # pos, index, self, and peg image
        self.old_score_peg = Peg(self.dots[122], 1, self, image)
        self.pegs = [self.score_peg, self.old_score_peg]
        peg_sprites.add(self.score_peg, self.old_score_peg)
        
        self.gameover_sprite = pygame.sprite.Sprite()
        self.gameover_sprite.image = pygame.image.load('../ExternalData/UI/gameover_red.png').convert_alpha()
        self.gameover_sprite.rect = self.gameover_sprite.image.get_rect(center = (566, 620))

        self.hand_score_pos = (540, 710)
        self.hand_score_sprite = pygame.sprite.Sprite()
        self.hand_score_sprite.image, self.hand_score_sprite.rect = self.get_surf(f'+{self.hand_score}',self.hand_score_pos, medium_font, False)
        self.hand_score_pos_offset = Vector2(140, 160)



class CPUPlayer(Player):
    def __init__(self, peg_sprites, player_name, card_sprites, scorekeeper, hand_score_sprites):
        super().__init__(peg_sprites, player_name, card_sprites, scorekeeper, hand_score_sprites)
        
        self.total_score_pos = (127, 64)
        self.total_wins_pos = (200, 64)
        

        self.scorecard = ScoreCard((566, 0), self.name)
        self.peg_score_pos = (0, 268)
        self.hand_pos = Vector2(402, 42)
        self.cards_played_pos_y = 272
        self.dots = CPU_dots
        image = pygame.image.load('../ExternalData/pegs/peg_blue.png').convert_alpha()

        self.score_peg = Peg(self.dots[0], 2, self, image)
        self.old_score_peg = Peg(self.dots[122], 3, self, image)
        self.show_scorecard_button.image = pygame.image.load('../ExternalData/UI/CPU_score.png').convert_alpha()
        self.show_scorecard_button.rect = self.show_scorecard_button.image.get_rect(midtop = (566, 0))
        self.pegs = [self.score_peg, self.old_score_peg]
        peg_sprites.add(self.score_peg, self.old_score_peg)
        
        self.gameover_sprite = pygame.sprite.Sprite()
        self.gameover_sprite.image = pygame.image.load('../ExternalData/UI/gameover_blue.png').convert_alpha()
        self.gameover_sprite.rect = self.gameover_sprite.image.get_rect(center = (566, 140))

        self.hand_score_pos = (560, 70)
        self.hand_score_sprite = pygame.sprite.Sprite()
        self.hand_score_sprite.image, self.hand_score_sprite.rect = self.get_surf(f'+{self.hand_score}',self.hand_score_pos, medium_font, False)
        self.hand_score_pos_offset = Vector2(140, 0)
        
    def get_CPU_card(self, seq, running_count): # used during pegging state, returns CPU card selection
        value_of_last_card = 0
        CPU_card = None
        last_card_played_value = 0
        if seq:
            last_card_played_value = seq[-1].value

        playable_cards = [card for card in self.hand if min(card.value, 10) + running_count < 32]
        for card in playable_cards:
            if min(card.value, 10) + running_count == 15 or min(card.value, 10) + running_count == 31:
                CPU_card = card
            if card.value == last_card_played_value:
                CPU_card = card
        if playable_cards and not CPU_card:
            CPU_card = choice(playable_cards)
        if CPU_card:
            CPU_card.image = CPU_card.front
            self.card_sprites.remove(CPU_card)
            self.card_sprites.add(CPU_card)
        return CPU_card
        
    def choose_discards(self): # populates self.discards for collection to crib hand
        possible_hands = []
        for subset in combinations(self.hand, 4):
            listset = list(subset) 
            listset = sorted(listset, key=self.sort_c)
            possible_hands.append([subset, self.score_four(listset)])
        max_score = 0
        max_hands = []
        max_hand = [self.hand[0], self.hand[1], self.hand[2], self.hand[3]]
        for hand_and_score in possible_hands:
            new_score = hand_and_score[1]
            if new_score > max_score:
                max_hands = [hand_and_score[0]]
                max_score = new_score
            elif new_score == max_score:
                max_hands.append(hand_and_score[0])
        max_hand = choice(max_hands)
        self.discards = [card for card in self.hand if card not in max_hand]

    def score_four(self, hand): # used during CPU discard selection
                                # returns score for 1 of the 15 possible 4 card hands of the 6 cards dealt
        hand = sorted(hand, key=self.sort_c)
        score = 0
        runs4 = False

        for index, card in enumerate(hand): # 15s
            for subset in combinations(hand, index + 2):
                if sum([min(card.value, 10) for card in subset]) == 15:
                    score += 2
                    
        for subset in combinations(hand, 2): # pairs
            if subset[0].value == subset[1].value:
                score += 2
        
        v = [card.value for card in hand] # run of 4
        if v[1] == v[0] + 1 and v[2] == v[0] + 2 and v[3] == v[0] + 3:
            score += 4
            runs4 = True

        if not runs4:
            for subset in combinations(hand, 3): # runs of 3
                if subset[0].value + 1 == subset[1].value and subset[1].value + 1 == subset[2].value:
                    score += 3
                
        if all([card.suit == hand[0].suit for card in hand]): # suits 4
            score += 4

        return score
        


class Peg(pygame.sprite.Sprite):
    def __init__(self, pos, index, player, image):
        super().__init__()
        self.pos = Vector2(pos)
        self.image = image
        self.rect = self.image.get_rect(topleft = self.pos)

        self.waypoints = []
        self.movement_speed = .8
        self.direction = Vector2()
        self.active = False
        self.target = Vector2()
        self.index = index
        self.player = player
        self.is_resetting = False

    # def reset(self):
    #     homes = [(980, 686), (980, 698), (1008, 686), (1008, 698)]
    #     self.waypoints = [homes[self.index]]
    #     self.is_resetting = True
    #     self.active = True
        
    def update(self, dt):
        if self.active:
            if self.is_resetting:
                self.reset_peg(dt)
                return
            dd = self.pos.distance_squared_to(self.waypoints[0])
            if dd < 100 and len(self.waypoints) > 1: 
                self.waypoints.pop(0)
            d = Vector2(self.waypoints[0] - self.pos)
            if d.length() > 0:
                d.normalize_ip()
            self.pos += d * self.movement_speed * dt
            self.rect.topleft = (round(self.pos.x), round(self.pos.y))
            if len(self.waypoints) < 9:
                d = (Vector2(self.target) - self.pos).length()
                if d < 2:
                    self.pos = Vector2(self.target)
                    self.rect.topleft = (round(self.pos.x), round(self.pos.y))
                    self.active = False
                    self.movement_speed = .8
                    self.player.update_total_score()
                    return
                self.movement_speed = d * .008

    def reset_peg(self, dt):
        dist = Vector2(self.waypoints[0]) - self.pos
        d = dist
        if dist.length() > 0:
            d = dist.normalize()
        self.pos += d * self.movement_speed * dt
        self.rect.topleft = (round(self.pos.x), round(self.pos.y))
        dist = (Vector2(self.waypoints[0]) - self.pos).length()
        if dist < 100:
            self.movement_speed = dist * .008
        if dist < 1:
            self.rect.topleft = self.waypoints[0]
            self.pos = Vector2(self.rect.topleft)
            self.movement_speed = .8
            self.active = False
            self.is_resetting = False