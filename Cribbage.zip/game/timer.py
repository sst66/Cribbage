

class Timer:
    def __init__(self, duration, func = None):
        self.duration = duration
        self.func = func
        self.active = False
        self.elapsed_time = 0

    def activate(self):
        self.active = True
        self.elapsed_time = 0

    def deactivate(self):
        self.active = False

    def update(self, dt):
        if self.active:
            self.elapsed_time += dt
            if self.elapsed_time >= self.duration:
                self.deactivate()
                if self.func:
                    self.func()